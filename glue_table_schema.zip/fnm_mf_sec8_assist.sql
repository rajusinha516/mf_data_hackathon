CREATE EXTERNAL TABLE `fnm_mf_sec8_assist`(
  `contract_number` string,
  `property_id` bigint,
  `property_name_text` string,
  `tracs_effective_date` string,
  `tracs_overall_expiration_date` string,
  `tracs_overall_exp_fiscal_year` bigint,
  `tracs_overall_expire_quarter` string,
  `tracs_current_expiration_date` string,
  `tracs_status_name` string,
  `contract_term_months_qty` bigint,
  `assisted_units_count` bigint,
  `is_hud_administered_ind` string,
  `is_acc_old_ind` string,
  `is_acc_performance_based_ind` string,
  `contract_doc_type_code` string,
  `program_type_name` string,
  `program_type_group_code` string,
  `program_type_group_name` string,
  `rent_to_fmr_ratio` double,
  `rent_to_fmr_description` string,
  `0br_count` double,
  `1br_count` double,
  `2br_count` double,
  `3br_count` double,
  `4br_count` double,
  `5plusbr_count` double,
  `0br_fmr` double,
  `1br_fmr` double,
  `2br_fmr` double,
  `3br_fmr` double,
  `4br_fmr` double)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '|'
STORED AS INPUTFORMAT
  'org.apache.hadoop.mapred.TextInputFormat'
OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  's3://fnm-hackathon-mfdata/sec8_data_csv/mf_sec8_assist/'
TBLPROPERTIES (
  'CrawlerSchemaDeserializerVersion'='1.0',
  'CrawlerSchemaSerializerVersion'='1.0',
  'UPDATED_BY_CRAWLER'='mf_data_sec8',
  'areColumnsQuoted'='false',
  'averageRecordSize'='387',
  'classification'='csv',
  'columnsOrdered'='true',
  'compressionType'='none',
  'delimiter'='|',
  'objectCount'='1',
  'recordCount'='19085',
  'sizeKey'='7386061',
  'skip.header.line.count'='1',
  'typeOfData'='file')
