CREATE EXTERNAL TABLE `fnm_mf_sec8_inspection`(
  `rems_property_id` bigint,
  `has_active_financing_ind` string,
  `has_active_assistance_ind` string,
  `inspection_id_1` bigint,
  `inspection_score1` string,
  `release_date_1` string,
  `inspection_id_2` double,
  `inspection_score2` string,
  `release_date_2` string,
  `inspection_id_3` double,
  `inspection_score3` string,
  `release_date_3` string,
  `property_name` string,
  `state_name_text` string,
  `city` string,
  `state_code` string,
  `inspection_score1_no` bigint,
  `inspection_score1_cat` string,
  `inspection_score2_no` bigint,
  `inspection_score2_cat` string,
  `inspection_score3_no` bigint,
  `inspection_score3_cat` string)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '|'
STORED AS INPUTFORMAT
  'org.apache.hadoop.mapred.TextInputFormat'
OUTPUTFORMAT
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  's3://fnm-hackathon-mfdata/sec8_data_csv/mf_sec8_inspection/'
TBLPROPERTIES (
  'CrawlerSchemaDeserializerVersion'='1.0',
  'CrawlerSchemaSerializerVersion'='1.0',
  'UPDATED_BY_CRAWLER'='mf_data_sec8',
  'areColumnsQuoted'='false',
  'averageRecordSize'='289',
  'classification'='csv',
  'columnsOrdered'='true',
  'compressionType'='none',
  'delimiter'='|',
  'objectCount'='1',
  'recordCount'='21129',
  'sizeKey'='6106496',
  'skip.header.line.count'='1',
  'typeOfData'='file')