import json
from fuzzywuzzy import fuzz

def normalize_address(address_string):
    return address_string.strip().upper()

def lambda_handler(event, context):
    # Print the incoming event
    print(f"Incoming event: {json.dumps(event)}")
    
    property_name1 = event.get('property_name1', '').strip().upper()
    property_name2 = event.get('property_name2', '').strip().upper()
    address1 = normalize_address(event.get('address1', ''))
    address2 = normalize_address(event.get('address2', ''))
    
    # Calculate similarity for property names and addresses
    property_name_similarity = fuzz.ratio(property_name1, property_name2) if property_name1 and property_name2 else 0
    address_similarity = fuzz.ratio(address1, address2)
    
    # Define weights for combined similarity score
    if property_name1 and property_name2:
        property_name_weight = 0.5
        address_weight = 0.5
    else:
        property_name_weight = 0.0
        address_weight = 1.0
    
    # Calculate the combined similarity score
    combined_similarity = (property_name_similarity * property_name_weight) + (address_similarity * address_weight)
    
    # Adjust combined similarity if property names are absent
    if not property_name1 or not property_name2:
        combined_similarity = address_similarity  # Assign all weight to address similarity
    
    result = {
        'property_name1': property_name1,
        'property_name2': property_name2,
        'property_name_similarity': property_name_similarity,
        'address1': address1,
        'address2': address2,
        'address_similarity': address_similarity,
        'combined_similarity': combined_similarity
    }
    
    # Print the result
    print(f"Result: {json.dumps(result)}")
    
    return {
        'statusCode': 200,
        'body': json.dumps(result)
    }
