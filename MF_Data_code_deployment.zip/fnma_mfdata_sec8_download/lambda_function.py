import logging
import requests
from bs4 import BeautifulSoup
import os
import hashlib
from urllib.parse import urljoin
import boto3
from botocore.exceptions import ClientError
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

# Initialize logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client('s3')


def get_session():
    session = requests.Session()
    retry = Retry(
        total=5,  # Total number of retries
        read=5,  # Number of retries on read errors
        connect=5,  # Number of retries on connection errors
        backoff_factor=0.3,  # Backoff factor for delays between retries
        status_forcelist=(500, 502, 504)  # Retry on these status codes
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('https://', adapter)
    session.mount('http://', adapter)
    return session


def fetch_webpage(url):
    session = get_session()
    response = session.get(url, timeout=10)
    response.raise_for_status()
    return response.content


def find_file_link(soup, link_text):
    for link in soup.find_all('a', href=True):
        if link_text in link.text:
            return link['href']
    return None


def download_file(url, bucket, key):
    session = get_session()
    response = session.get(url, timeout=10)
    response.raise_for_status()
    s3_client.put_object(Body=response.content, Bucket=bucket, Key=key)


def generate_md5(bucket, key):
    obj = s3_client.get_object(Bucket=bucket, Key=key)
    hash_md5 = hashlib.md5()
    for chunk in iter(lambda: obj['Body'].read(4096), b""):
        hash_md5.update(chunk)
    return hash_md5.hexdigest()


def upload_to_s3(bucket, key, data):
    s3_client.put_object(Body=data, Bucket=bucket, Key=key)


def get_s3_object_md5(bucket, key):
    try:
        response = s3_client.head_object(Bucket=bucket, Key=key)
        return response['ETag'].strip('"')
    except ClientError as e:
        if e.response['Error']['Code'] == '404':
            return None  # Object does not exist
        else:
            raise  # Raise the error if it's not a 404


def process_file(base_url, path, link_texts, s3_bucket, s3_stg_prefix, s3_land_prefix):
    url = urljoin(base_url, path)
    logger.info(f"Fetching webpage: {url}")

    try:
        html_content = fetch_webpage(url)
        soup = BeautifulSoup(html_content, 'html.parser')

        results = {}
        for link_text in link_texts:
            file_url = find_file_link(soup, link_text)
            if file_url:
                file_url = urljoin(base_url, file_url)
                logger.info(f"Found file URL for '{link_text}': {file_url}")
                file_name = file_url.split('/')[-1]
                stg_key = os.path.join(s3_stg_prefix, file_name)

                download_file(file_url, s3_bucket, stg_key)
                logger.info(f"File '{file_name}' downloaded to staging area")

                stg_md5 = generate_md5(s3_bucket, stg_key)
                logger.info(f"MD5 for staging file '{file_name}': {stg_md5}")

                land_key = os.path.join(s3_land_prefix, file_name)
                land_md5 = get_s3_object_md5(s3_bucket, land_key)

                if land_md5 is None or stg_md5 != land_md5:
                    logger.info(f"MD5 mismatch or file not present in land area. Moving '{file_name}' to land area")

                    # Copy object from staging to land
                    s3_client.copy_object(Bucket=s3_bucket, Key=land_key,
                                          CopySource={'Bucket': s3_bucket, 'Key': stg_key})

                    # Clean up staging object after copying to land
                    s3_client.delete_object(Bucket=s3_bucket, Key=stg_key)
                    logger.info(f"Staging object '{stg_key}' deleted after copying to land")

                    results[link_text] = {
                        'statusCode': 200,
                        'body': f'File copied to land area: s3://{s3_bucket}/{land_key}'
                    }
                else:
                    logger.info(f"No changes detected for '{file_name}'. Skipping upload.")

                    results[link_text] = {
                        'statusCode': 304,
                        'body': f'No changes detected for file "{file_name}". Skipping upload.'
                    }

            else:
                logger.error(f"File link '{link_text}' not found on the webpage")
                results[link_text] = {
                    'statusCode': 404,
                    'body': f'File link "{link_text}" not found on the webpage'
                }

        return results

    except requests.exceptions.RequestException as e:
        logger.error(f"Request error: {e}")
        return {
            'statusCode': 500,
            'body': f'Request error: {e}'
        }
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return {
            'statusCode': 500,
            'body': f'Unexpected error: {e}'
        }


def lambda_handler(event, context):
    try:
        # Parameters for both files
        base_url = 'https://www.hud.gov'
        path1 = '/program_offices/housing/mfh/exp/mfhdiscl'
        link_texts1 = [
            'MF_Properties_with_Assistance_&_Sec8_Contracts',
            'MF_Assistance_&_Sec8_Contracts'
        ]
        path2 = '/program_offices/housing/mfh/rems/remsinspecscores/remsphysinspscores'
        link_texts2 = [
            'REAC Physical Inspections Scores and Release Dates'
        ]
        s3_bucket = 'fnm-hackathon-mfdata'
        s3_stg_prefix = 'stg/'
        s3_land_prefix = 'land/'

        results1 = process_file(base_url, path1, link_texts1, s3_bucket, s3_stg_prefix, s3_land_prefix)
        results2 = process_file(base_url, path2, link_texts2, s3_bucket, s3_stg_prefix, s3_land_prefix)

        return {**results1, **results2}

    except Exception as e:
        logger.error(f"Lambda handler error: {e}")
        return {
            'statusCode': 500,
            'body': f'Lambda handler error: {e}'
        }
