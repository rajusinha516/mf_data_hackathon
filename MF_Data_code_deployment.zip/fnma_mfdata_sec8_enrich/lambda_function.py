import os
import logging
import boto3
import pandas as pd
from io import BytesIO
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize S3 client
s3_client = boto3.client('s3')

def list_excel_files(bucket_name, prefix=''):
    try:
        logger.info(f"Listing Excel files in bucket: {bucket_name} with prefix: {prefix}")
        objects = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
        excel_files = [obj['Key'] for obj in objects.get('Contents', []) if obj['Key'].endswith(('.xls', '.xlsx'))]
        return excel_files
    except Exception as e:
        logger.error(f"Error listing Excel files in S3: {e}")
        raise

def read_excel_from_s3(bucket_name, key):
    try:
        logger.info(f"Reading Excel file from bucket: {bucket_name}, key: {key}")
        response = s3_client.get_object(Bucket=bucket_name, Key=key)
        excel_content = response['Body'].read()
        return excel_content
    except s3_client.exceptions.NoSuchKey:
        logger.error(f"No such key found: {key} in bucket: {bucket_name}")
        raise
    except Exception as e:
        logger.error(f"Error reading Excel file from S3: {e}")
        raise

def convert_excel_to_csv(excel_content, source_key):
    try:
        logger.info("Converting Excel content to CSV")
        df = pd.read_excel(BytesIO(excel_content))

        # Replace spaces with underscores in column names
        df.columns = df.columns.str.replace(' ', '_')

        # Check if the file has 'Inspection' in its name and process accordingly
        if 'Inspection' in source_key:
            for col in ['Inspection_Score1', 'Inspection_Score2', 'Inspection_Score3']:
                if col in df.columns:
                    # Split the score into numeric and categorical parts
                    df[f'{col}_No'] = df[col].str.extract(r'(\d+)')
                    df[f'{col}_Cat'] = df[col].str.extract(r'([a-zA-Z*]+)')

        # Geocoding logic for 'Properties' files
        if 'Properties' in source_key:
            # Trim white spaces from 'address_line1_text' and 'city_name_text' columns
            df['address_line1_text'] = df['address_line1_text'].str.strip()
            df['city_name_text'] = df['city_name_text'].str.strip()

            geolocator = Nominatim(user_agent="App", timeout=10)

            # Filter rows where state_code is 'NY' and city_name_text contains 'Brooklyn'
            mask = (df['state_code'].str.upper() == 'NY') & (df['city_name_text'].str.contains('Brooklyn', case=False, na=False))
            filtered_df = df[mask]

            # Function to handle geocoding retries and timeouts
            def geocode_with_retry(address):
                try:
                    return geolocator.geocode(address)
                except GeocoderTimedOut:
                    logger.warning(f"Geocoding request timed out for address: {address}. Retrying...")
                    return geocode_with_retry(address)

            # Geocode addresses and add latitude and longitude to DataFrame
            for index, row in filtered_df.iterrows():
                address = f"{row['address_line1_text']}, {row['city_name_text']}, NY {row['zip_code']}, USA"
                logger.info(f"Geocoding address: {address}")
                location = geocode_with_retry(address)
                if location:
                    df.loc[index, 'Latitude'] = location.latitude
                    df.loc[index, 'Longitude'] = location.longitude
                else:
                    logger.warning(f"Unable to geocode address: {address}")

        csv_buffer = BytesIO()
        df.to_csv(csv_buffer, index=False, sep='|')

        csv_buffer.seek(0)
        return csv_buffer
    except Exception as e:
        logger.error(f"Error converting Excel to CSV: {e}")
        raise

def upload_csv_to_s3(bucket_name, key, csv_buffer):
    try:
        logger.info(f"Uploading CSV to bucket: {bucket_name}, key: {key}")
        s3_client.upload_fileobj(csv_buffer, bucket_name, key)
    except Exception as e:
        logger.error(f"Error uploading CSV to S3: {e}")
        raise

def determine_destination_key(source_key):
    try:
        filename = os.path.basename(source_key)
        name_part = filename.split('_')[0]
        if 'Inspection' in filename:
            folder_name = 'sec8_data_csv/mf_sec8_inspection'
        elif 'Properties' in filename:
            folder_name = 'sec8_data_csv/mf_prop_sec8_assist'
        else:
            folder_name = 'sec8_data_csv/mf_sec8_assist'

        # Correctly replace .xls or .xlsx with .csv
        if filename.endswith('.xls'):
            filename = filename[:-4] + '.csv'
        elif filename.endswith('.xlsx'):
            filename = filename[:-5] + '.csv'

        destination_key = f"{folder_name}/{filename}"
        destination_key = os.path.normpath(destination_key)

        return destination_key
    except Exception as e:
        logger.error(f"Error determining destination key: {e}")
        raise

def lambda_handler(event, context):
    source_bucket = 'fnm-hackathon-mfdata'
    source_prefix = 'land/'
    destination_bucket = 'fnm-hackathon-mfdata'

    try:
        # List all Excel files in the source bucket
        excel_files = list_excel_files(source_bucket, source_prefix)

        for source_key in excel_files:
            try:
                # Read Excel file from S3
                excel_content = read_excel_from_s3(source_bucket, source_key)

                # Convert Excel to CSV
                csv_buffer = convert_excel_to_csv(excel_content, source_key)

                # Determine the destination key based on the filename pattern
                destination_key = determine_destination_key(source_key)

                # Upload CSV to S3
                upload_csv_to_s3(destination_bucket, destination_key, csv_buffer)

                logger.info(f"Successfully processed and uploaded {source_key} to {destination_key}")
            except Exception as e:
                logger.error(f"Error processing file {source_key}: {e}")

        return {
            'statusCode': 200,
            'body': 'Successfully processed all Excel files'
        }
    except Exception as e:
        logger.error(f"Error in lambda_handler: {e}")
        return {
            'statusCode': 500,
            'body': str(e)
        }
