import logging
import json
import boto3
import csv
import io
import os
from datetime import datetime, timedelta

# Initialize logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

file_key_param = os.environ.get('file_key')
bucket_name_param = os.environ.get('bucket_name')
state_code_param = os.environ.get('state_code')

s3 = boto3.client('s3')
sns = boto3.client('sns')

SNS_TOPIC_ARN = 'arn:aws:sns:us-east-1:590183975694:DowngradedInspectionsReport'  # Replace with your SNS topic ARN

def lambda_handler(event, context):
    # Configuration
    #bucket_name = 'fnm-hackathon-mfdata'  # Replace with your S3 bucket name
    #file_key = 'sec8_data_csv/mf_sec8_inspection/MF_Inspection_Report06032024.csv'  # Replace with your S3 file key
    
    bucket_name = bucket_name_param  # Replace with your S3 bucket name
    file_key = file_key_param  # Replace with your S3 file key
    
    # Get the CSV file from S3
    response = s3.get_object(Bucket=bucket_name, Key=file_key)
    content = response['Body'].read().decode('utf-8')
    
    # Read the CSV file
    records = []
    csv_reader = csv.DictReader(io.StringIO(content), delimiter='|')
    for row in csv_reader:
        #print('now processing record', row.get('REMS_Property_Id'))
        release_date_1_str = row.get('Release_Date_1')
        inspection_score_1_str = row.get('Inspection_Score1_No')
        inspection_score_2_str = row.get('Inspection_Score2_No')
        state_code = row.get('state_code')

        # Skip records with null values in the necessary fields
        if not release_date_1_str or not inspection_score_1_str or not inspection_score_2_str or not state_code:
            continue
        
        try:
            release_date_1 = datetime.strptime(release_date_1_str, '%Y-%m-%d %H:%M:%S')
            inspection_score_1 = int(inspection_score_1_str)
            inspection_score_2 = int(inspection_score_2_str)
        except ValueError:
            # Skip records with invalid date or score formats
            continue

        if (release_date_1 >= datetime.now() - timedelta(weeks=20)) and (inspection_score_1 < inspection_score_2) and (state_code_param == state_code):
            print(f'now processing record {release_date_1}, {inspection_score_1}, {inspection_score_2}')
            records.append(row)
    
    # Send records to SNS
    if records:
        print('count of records identified is', len(records))
        message = json.dumps(records)
        sns.publish(TopicArn=SNS_TOPIC_ARN, Message=message)
        
    return {
        'statusCode': 200,
        'body': json.dumps('Successfully processed and sent records to SNS')
    }
